package com.capgemini.exceptions;

public class SearchByNullException extends Exception {

}
