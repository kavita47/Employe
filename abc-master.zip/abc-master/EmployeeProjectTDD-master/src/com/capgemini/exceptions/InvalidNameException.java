package com.capgemini.exceptions;

public class InvalidNameException extends Exception {

}
